﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Runtime.ExceptionServices;

namespace God
{
    class Program
    {
        
        static void Main(string[] args)
        {
            Simulator m = new Simulator();

            m.Run();
        }
    }
}
