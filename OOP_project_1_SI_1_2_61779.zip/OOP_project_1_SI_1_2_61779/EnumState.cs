﻿public enum State 
{   Moving,
    Attacking,
    Eating,
    SearchingForFood,
    Sleeping,
    Analyzing,
    Unknown 
}
