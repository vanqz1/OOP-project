﻿public enum EntityType
{ 
    entity,
    animal,
    human,
    god,
    unknown

}
